package br.com.pplip1.novocrudrest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerPova {
	@GetMapping("/votos")
 public String BoaProvaController() {
	 return "Boa Prova :-)";
 }
}
