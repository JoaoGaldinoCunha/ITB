package br.com.pplip1.novocrudrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NovocrudrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(NovocrudrestApplication.class, args);
	}

}
