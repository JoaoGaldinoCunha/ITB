package br.com.pplip1.novocrudrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NovocrudrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
