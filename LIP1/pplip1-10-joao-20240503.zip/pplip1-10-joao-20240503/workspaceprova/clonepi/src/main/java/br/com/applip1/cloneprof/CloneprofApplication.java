package br.com.applip1.cloneprof;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloneprofApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloneprofApplication.class, args);
	}

}
